package com.example.student;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Home_Admin extends AppCompatActivity {
    private ListView notelist;
    TextView nom;
    TextView prenom;
   public String cours,item;

     TextView nom_txt,prenom_txt,line_email;
    EditText cote;
    Button button;
    String[] items = {"math","geo","histoire","philosophie","religion","physique","anatomie"};
    AutoCompleteTextView autoCompleteTextView;
    ArrayAdapter<String> adapteritem;


    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        initwidgets();
        chercher();
        autoCompleteTextView.setAdapter(adapteritem);
        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                item = adapterView.getItemAtPosition(i).toString();
                Toast.makeText(Home_Admin.this, "Item : "+item, Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void initwidgets() {


        autoCompleteTextView = findViewById(R.id.auto_complete);
        adapteritem = new ArrayAdapter<String>(this,R.layout.item,items);

        nom_txt = findViewById(R.id.nomtxt2);
        prenom_txt = findViewById(R.id.prenom2);
        cote = findViewById(R.id.cote);


    }
    public void save_cote(View view) {
        Intent home = getIntent();
        int b = Integer.parseInt(cote.getText().toString());
if(b>=0 && b<=20){
    cours = item;
    Database db = new Database(Home_Admin.this);
    Intent hom = getIntent();
    Boolean a = db.insert_cote(nom_txt.getText().toString().trim(), prenom_txt.getText().toString().trim(), cours, Integer.valueOf(cote.getText().toString().trim()),hom.getStringExtra("email"));
    if (a == true) {
        Toast.makeText(Home_Admin.this, "Insertion reussi avec Succes", Toast.LENGTH_SHORT).show();

    } else {
        Toast.makeText(Home_Admin.this, "Echeck", Toast.LENGTH_SHORT).show();
    }
}
else {
    Toast.makeText(this, "Saisir un nombre compris entre 1 et 20", Toast.LENGTH_SHORT).show();
}

        }

    public void chercher(){
Intent home = getIntent();
if(home.hasExtra("email")){
    Database db = new Database(Home_Admin.this);
    db.populatelist(home.getStringExtra("email"),nom_txt,prenom_txt);
}


    }
    public  void logout(View view){
        Intent log = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(log);
        finish();
    }



}