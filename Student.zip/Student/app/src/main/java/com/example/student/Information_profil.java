package com.example.student;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Information_profil extends AppCompatActivity {
TextView prenom,nom,age,email;
ImageView image_profil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information);
        initwidgets();
        retour();
        affiche();
    }
    public  void retour(){
        Intent intent = getIntent();
        if(intent.hasExtra("with")){
            prenom.setText(intent.getStringExtra("prenom"));
            nom.setText(intent.getStringExtra("nom"));
            age.setText(intent.getStringExtra("age"));
            email.setText(intent.getStringExtra("ema"));
            String picture = intent.getStringExtra("image");
            Uri p = Uri.parse(picture);
            image_profil.setImageURI(p);
        }
       else if(intent.hasExtra("without")){
            prenom.setText(intent.getStringExtra("prenom"));
            nom.setText(intent.getStringExtra("nom"));
            age.setText(intent.getStringExtra("age"));
            email.setText(intent.getStringExtra("ema"));
            Database db = new Database(Information_profil.this);
            db.profil_image(intent.getStringExtra("ema"),image_profil);

        }
    }

    private void initwidgets() {
        prenom = findViewById(R.id.prenom_profil);
        nom = findViewById(R.id.nom_profil);
        age = findViewById(R.id.age_profil);
        email = findViewById(R.id.email_profil);
        image_profil = findViewById(R.id.imageView3);
    }
public void affiche(){
    Intent profil = getIntent();
    if(profil.hasExtra("email")){
        Database db = new Database(Information_profil.this);
        db.affichage_profil(profil.getStringExtra("email"),prenom,nom,age,email,image_profil);

    }

}
public  void modifiez_profil(View view){
        Intent modif = new Intent(getApplicationContext(),Profil.class);
        modif.putExtra("prenom",prenom.getText().toString());
    modif.putExtra("nom",nom.getText().toString());
    modif.putExtra("age",age.getText().toString());
    modif.putExtra("email",email.getText().toString());

    startActivity(modif);
    finish();

}
    public  void logout(View view){
        Intent log = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(log);
        finish();
    }
    public  void cote(View view){
        Intent log = new Intent(getApplicationContext(),Home_Student.class);
        startActivity(log);
        finish();
    }

}