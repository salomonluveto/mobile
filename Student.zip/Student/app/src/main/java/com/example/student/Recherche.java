package com.example.student;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Recherche extends AppCompatActivity {
    TextView nom,email;
    EditText recherche;
    Button button;
    String emai,nm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recherche);
        initwidgets();

    }

    private void initwidgets() {
        nom = findViewById(R.id.textView_r);
        email = findViewById(R.id.textView_email);
        recherche = findViewById(R.id.recherche);
        button = findViewById(R.id.button_r);
    }
    public void chercher(View view){
        String rech = recherche.getText().toString().trim();
        Database db = new Database(Recherche.this);
        db.recherche(rech,nom,email);
    }
   public void new_page(View view){
        emai = email.getText().toString().trim();

        Intent home = new Intent(getApplicationContext(),Home_Admin.class);

        home.putExtra("email",emai);
        startActivity(home);

    }
    public  void logout(View view){
        Intent log = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(log);
        finish();
    }

}