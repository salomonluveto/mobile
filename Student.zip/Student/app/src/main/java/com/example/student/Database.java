package com.example.student;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.FileInputStream;
import java.io.IOError;
import java.io.IOException;

public class Database extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME = "L3lmd.db";
    public Database(@Nullable Context context) {
        super(context,DATABASE_NAME,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Etudiant(email Text primary key,prenom Text,nom Text, age integer, password Text,image Text)");
        db.execSQL("create table cotes(id_cote integer primary key,nom Text, prenom Text, cours Text, cote integer,email Text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("drop table if exists Etudiant");
        db.execSQL("drop table if exists identite");
        db.execSQL("drop table if exists cotes");
        onCreate(db);
    }

   public Boolean inserData( String email, String prenom, String nom, int age,  String password){

            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("email", email);
            cv.put("prenom", prenom);
            cv.put("nom", nom);
            cv.put("age", age);
            cv.put("password", password);
            long result = db.insert("Etudiant", null, cv);
            if (result == -1) {
                return false;
            } else {
                return true;
            }


    }
    public Boolean modifdata(String email, String prenom, String nom, String age, Uri image){

        SQLiteDatabase db = this.getWritableDatabase();
        try {

            ContentValues cv = new ContentValues();
            cv.put("email", email);
            cv.put("prenom", prenom);
            cv.put("nom", nom);
            cv.put("age", age);
            cv.put("image",image.toString());

            long result = db.update("Etudiant", cv, "email = ?", new String[]{email});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        catch (Exception e){
            e.printStackTrace();
            return false;
        }



    }
    public Boolean modifdata1(String email, String prenom, String nom, String age){

        SQLiteDatabase db = this.getWritableDatabase();
        try {

            ContentValues cv = new ContentValues();
            cv.put("email", email);
            cv.put("prenom", prenom);
            cv.put("nom", nom);
            cv.put("age", age);


            long result = db.update("Etudiant", cv, "email = ?", new String[]{email});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }
        catch (Exception e){
            e.printStackTrace();
            return false;
        }



    }

    public Boolean insert_cote( String nom, String prenom, String cours, int cote,String email){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nom", nom);
        cv.put("prenom", prenom);
        cv.put("cours", cours);
        cv.put("cote", cote);
        cv.put("email",email);


        long result = db.insert("cotes", null, cv);
        if (result == -1) {
            return false;
        } else {
            return true;
        }


    }

    /*
    public boolean addNote(Note note){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title",note.getTitle());
        cv.put("description",note.getDescription());
        long result = sqLiteDatabase.insert("notes",null,cv);
        if(result == -1){
            return false;
        }
        else {
            return true;
        }
    }

     */

    public Boolean checkEmail(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from allusers where email = ?", new String[]{email});

        if(cursor.getCount() >0){
            return true;
        }
        else {
            return false;
        }
    }

    public Boolean checkEmailPassword(String emai, String password){

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from Etudiant where email = ? and password = ?", new String[]{emai,password});
        if(cursor.getCount() >0){
            return true;
        }
        else {
            return false;
        }
    }
    public Boolean checkAdmin(String emai, String password){

        if(emai.equals("luveto@gmail.com") && password.equals("123456")){
            return true;
        }
        else {
            return false;
        }
    }

    public void populatelist(String rec, TextView n, TextView p){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM Etudiant WHERE email = ?",new String[]{rec})){
            if(result.getCount()!=0){
                while (result.moveToNext()){

                String    nom = result.getString(2);
                String    prenom = result.getString(1);

                n.setText(nom);
                p.setText(prenom);



                }
            }

        }
    }
    public void recherche(String rec,TextView n,TextView line){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM Etudiant WHERE nom = ?",new String[]{rec})){
            if(result.getCount()!=0){
                while (result.moveToNext()){

                    String    nom = result.getString(2);
                    String    prenom = result.getString(1);
                    String    email = result.getString(0);
                    line.setText(email);
                    n.setText(nom+"  "+prenom);



                }
            }

        }
    }
    public void affichage_cote(String email){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM cotes where email = ? ",new String[]{email})){
            if(result.getCount()!=0){

                while (result.moveToNext()){

                    String cours = result.getString(3);
                    String cote = result.getString(4);
                    Etudiant_identite identite  = new Etudiant_identite(cours,cote);
                    Etudiant_identite.identiteArrayList.add(identite);

                }

            }


        }
    }
    public void profil_image(String rec, ImageView imgp){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM Etudiant Where email =? ",new String[]{rec})){
            if(result.getCount()!=0){

                while (result.moveToNext()){

                    String image = result.getString(5);

                    if(image != null){
                        Uri img = Uri.parse(image);
                        imgp.setImageURI(img);
                    }



                }

            }


        }
    }
    public void affichage_profil(String rec, TextView p, TextView n, TextView a, TextView e, ImageView imgp){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM Etudiant Where email =? ",new String[]{rec})){
            if(result.getCount()!=0){

                while (result.moveToNext()){

                    String prenom = result.getString(1);
                    String nom = result.getString(2);
                    String age = result.getString(3);
                    String email = result.getString(0);
                    String image = result.getString(5);
                    p.setText(prenom);
                    n.setText(nom);
                    a.setText(age);
                    e.setText(email);
                    if(image != null){
                        Uri img = Uri.parse(image);
                        imgp.setImageURI(img);
                    }



                }

            }


        }
    }

    void affichage_modifl(String rec, String prenom, String nom, String age, String email){

        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        try (Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM Etudiant Where email =? ",new String[]{rec})){
            if(result.getCount()!=0){

                while (result.moveToNext()){
                    prenom = result.getString(1);
                    nom = result.getString(2);
                    age = result.getString(3);
                     email = result.getString(0);



                }

            }


        }
    }
/*
    public  void deletedata(Note note){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.delete("notes","title = ?", new String[]{note.getTitle()});
    }

     */
}
