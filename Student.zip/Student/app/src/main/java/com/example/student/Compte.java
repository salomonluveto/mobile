package com.example.student;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Compte extends AppCompatActivity {
    EditText prenom,nom,age,email,password;
    Button button_compte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compte);
        initwidgets();


    }

    public void initwidgets(){
        prenom = findViewById(R.id.prenom);
        nom = findViewById(R.id.nom);
        age = findViewById(R.id.age);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        button_compte = findViewById(R.id.button_compte);

    }
    public void savedata(View view){
        Database db = new Database(Compte.this);

       Boolean a = db.inserData(email.getText().toString().trim(),prenom.getText().toString().trim(),nom.getText().toString().trim(),Integer.valueOf(age.getText().toString().trim()), password.getText().toString().trim());
        if(a==true) {
            Toast.makeText(Compte.this, "Compte Créér avec Succes", Toast.LENGTH_SHORT).show();
            Intent connexion = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(connexion);
            finish();
        }
        else {
            Toast.makeText(Compte.this, "Echeck", Toast.LENGTH_SHORT).show();
        }
    }
}