package com.example.student;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText email, password;
    Button button_connexion, button_compte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initwidgets();
    }

    public void initwidgets(){
        email = findViewById(R.id.editTextTextEmailAddress);
        password = findViewById(R.id.editTextTextPassword);
        button_connexion = findViewById(R.id.button);
        button_compte = findViewById(R.id.button2);
    }
    public void connexion(View view){
        Database db = new Database(MainActivity.this);
        String emai = email.getText().toString().trim();
        String pass = password.getText().toString().trim();

        Boolean check = db.checkEmailPassword(emai,pass);
        Boolean admin = db.checkAdmin(emai,pass);
        String src;
        String email;



        if(check==true){
            src = emai;
            Intent home = new Intent(getApplicationContext(), Home_Student.class);
            home.putExtra("email",src);

            startActivity(home);
            finish();
        }
        else if(admin==true){

            Intent home = new Intent(getApplicationContext(), Recherche.class);

            startActivity(home);
            finish();

        }
        else {
            Toast.makeText(MainActivity.this, "Email ou Mot de Passe incorrect", Toast.LENGTH_SHORT).show();
        }

    }
    public void creation_compte(View view){
        Intent compte = new Intent(getApplicationContext(), Compte.class);
        startActivity(compte);
    }
}