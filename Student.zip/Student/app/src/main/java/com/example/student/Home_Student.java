package com.example.student;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class Home_Student extends AppCompatActivity {
    ListView listView;
    EditText email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_student);
        initwidgets();
        affichage();
        setNoteAdapter();



    }
    public  void initwidgets(){
       listView = findViewById(R.id.student_cote);
       email = findViewById(R.id.editTextTextEmailAddress);

    }
    public void affichage(){
        Intent home = getIntent();
        if(home.hasExtra("email")){
            Database db = new Database(Home_Student.this);

            db.affichage_cote(home.getStringExtra("email"));
        }

    }
    public  void profil(View view){
        Intent hom = getIntent();
        String prof = hom.getStringExtra("email");
      Intent profil = new Intent(getApplicationContext(),Information_profil.class);
      profil.putExtra("email",prof);
      startActivity(profil);


    }
    public  void logout(View view){
        Intent log = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(log);
        finish();
    }

    private void setNoteAdapter() {
EtudiantAdapter etudiantAdapter = new EtudiantAdapter(getApplicationContext(),Etudiant_identite.identiteArrayList);
listView.setAdapter(etudiantAdapter);

    }
}