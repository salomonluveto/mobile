package com.example.student;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class EtudiantAdapter extends ArrayAdapter<Etudiant_identite> {

    public EtudiantAdapter(Context context, List<Etudiant_identite> identites) {
        super(context,0, identites);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Etudiant_identite identite = getItem(position);
        if(convertView==null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.liste_cote, parent, false);
        }
        TextView cours = convertView.findViewById(R.id.cours);
        TextView cote = convertView.findViewById(R.id.cote1);


        cours.setText(identite.getCours());
        cote.setText(identite.getCote());


        return convertView;

    }
}

