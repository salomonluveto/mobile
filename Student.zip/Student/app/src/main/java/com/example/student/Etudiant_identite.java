package com.example.student;

import java.util.ArrayList;

public class Etudiant_identite {
    public static ArrayList<Etudiant_identite> identiteArrayList = new ArrayList();


    private String cours;
    private String  cote;
    private String nom;
    private  String prenom;



    public Etudiant_identite( String cours, String cote) {

        this.cours = cours;
        this.cote = cote;

    }

    public String getCours() {
        return cours;
    }

    public void setCours(String cours) {
        this.cours = cours;
    }

    public String getCote() {
        return cote;
    }

    public void setCote(String cote) {
        this.cote = cote;
    }


}
