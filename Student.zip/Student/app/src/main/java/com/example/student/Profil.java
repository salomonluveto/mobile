package com.example.student;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class Profil extends AppCompatActivity {

    private static final int GALLERY_REQ_CODE = 1000;
    int j;

    private ActivityResultLauncher<Intent> launcher;
    Uri imageUri;
    byte[] imgbyte;
    EditText nom, prenom, age, email;
    private Bitmap imageTostore;
    private Uri imagepath;

    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);
        image = findViewById(R.id.image);
        initwidgets();
        Button button = findViewById(R.id.btnimage);
        modif();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*
                Intent gallery = new Intent();
                gallery.setType("image/*");
                gallery.setAction(Intent.ACTION_GET_CONTENT);
                gallery.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(gallery,GALLERY_REQ_CODE);

                 */
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, GALLERY_REQ_CODE);

                /*
                Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                ActivityResultLauncher<Intent> launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                    if(result.getResultCode() == RESULT_OK && result.getData()!=null){
                        Uri imageUri = result.getData().getData();
                        image.setImageURI(imageUri);
                    }
                });
                launcher.launch(gallery);

                 */


/*
                launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result->{
                    if(result.getResultCode() == RESULT_OK && result.getData()!=null){
                        Uri imageUri = result.getData().getData();
                        image.setImageURI(imageUri);
                    }
                });
                launchGalleryIntent();

 */

            }
        });

    }


    private void launchGalleryIntent() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        launcher.launch(intent);
    }


    private void initwidgets() {
        prenom = findViewById(R.id.prenom_modif);
        nom = findViewById(R.id.nom_modif);
        age = findViewById(R.id.age_modif);
        email = findViewById(R.id.email_modif);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        imageUri = data.getData();
        if (requestCode == RESULT_OK && requestCode == GALLERY_REQ_CODE && data != null) {
            Uri imageUri2 = data.getData();
            /*    String[] filePathColumn = {MediaStore.Images.Media.DATA};
                Cursor cursor = getContentResolver().query(imageUri,filePathColumn,null,null,null);
                cursor.moveToFirst();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String picturepath = cursor.getString(columnIndex);
                cursor.close();
                image.setImageBitmap(BitmapFactory.decodeFile(picturepath));

             */
            image.setImageURI(imageUri2);
            j = 1;

        }

        image.setImageURI(imageUri);
        j = 1;
            /*
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer))!= -1){
                byteArrayOutputStream.write(buffer,0,length);
            }
            imgbyte = byteArrayOutputStream.toByteArray();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

             */


    }


    public void modif() {
        Intent profil = getIntent();
        String p = profil.getStringExtra("prenom");
        String n = profil.getStringExtra("nom");
        String a = profil.getStringExtra("age");
        String e = profil.getStringExtra("email");

        prenom.setText(p);
        nom.setText(n);
        age.setText(a);
        email.setText(e);
        Database db = new Database(Profil.this);
        db.profil_image(e, image);


    }

    public void modif_button(View view) {
        Database db = new Database(Profil.this);

        Uri img = imageUri;
        if (j == 1) {
            Boolean a = db.modifdata(email.getText().toString(), prenom.getText().toString(), nom.getText().toString(), age.getText().toString(), img);
            if (a == true) {
                Toast.makeText(this, "modification reussie", Toast.LENGTH_SHORT).show();
                Intent modif = new Intent(getApplicationContext(), Information_profil.class);

                modif.putExtra("prenom", prenom.getText().toString());
                modif.putExtra("nom", nom.getText().toString());
                modif.putExtra("age", age.getText().toString());
                modif.putExtra("ema", email.getText().toString());
                modif.putExtra("image", img.toString());
                modif.putExtra("with","with");

                startActivity(modif);
                finish();

            }
        }
        int k = 2;

        if (k == 2) {
            Boolean a = db.modifdata1(email.getText().toString(), prenom.getText().toString(), nom.getText().toString(), age.getText().toString());
            if (a == true) {
                Toast.makeText(this, "modification reussie", Toast.LENGTH_SHORT).show();
                Intent modif = new Intent(getApplicationContext(), Information_profil.class);

                modif.putExtra("prenom", prenom.getText().toString());
                modif.putExtra("nom", nom.getText().toString());
                modif.putExtra("age", age.getText().toString());
                modif.putExtra("ema", email.getText().toString());
                modif.putExtra("without","without");


                startActivity(modif);
                finish();
            }
        } else {
            Toast.makeText(this, "Echeck", Toast.LENGTH_SHORT).show();
        }

    }
}